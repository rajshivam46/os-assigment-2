print("script1: Hello from script1")
