print("script2: Doing some quick math...")
print("2 + 3 =", 2+3)
