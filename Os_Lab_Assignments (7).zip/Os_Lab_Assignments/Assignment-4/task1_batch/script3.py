print("script3: Bye from script3")
